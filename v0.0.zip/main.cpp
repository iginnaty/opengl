#include "graphics.h"
#include "g_util.h"

void runMainLoop(int val) {
    update();
    render();

    glutTimerFunc(1000 / SCREEN_FPS, runMainLoop, val);
}

int main(int argc, char* argv[]) {
    glutInit(&argc, argv);

    glutInitContextVersion(2, 1);

    glutInitDisplayMode(GLUT_DOUBLE);
    glutInitWindowSize(SCREEN_WIDTH, SCREEN_HEIGHT);
    glutCreateWindow("OpenGL");

    if (!initGL()) {
        std::cout << "Unable to initialize graphics library\n";
        return 1;
    }

    if (!loadMedia()) {
        std::cout << "Unable to load media\n";
        return 2;
    }

    glutKeyboardFunc(handleKeys);
    glutDisplayFunc(render);
    glutTimerFunc(1000 / SCREEN_FPS, runMainLoop, 0);

    glutMainLoop();

    return 0;
}
